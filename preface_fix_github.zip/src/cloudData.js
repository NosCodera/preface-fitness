import { backendClient } from './backend';



const TABLES = {

  membershipPlans: 'membership_plans',

  members: 'members',

  payments: 'payments',

  attendance: 'attendance',

  leads: 'leads',

  trainers: 'trainers',

  ptSessions: 'pt_sessions',

  progressRecords: 'progress_records',

  workoutPlans: 'workout_plans',

  dietPlans: 'diet_plans',

  communicationLogs: 'communication_logs',

  feedbacks: 'feedbacks',

  appSettings: 'app_settings',

};



function throwIfError(error, context) {

  if (error) throw new Error(`${context}: ${error.message}`);

}



async function getAuthenticatedUser() {

  const {

    data: { user },

    error,

  } = await backendClient.auth.getUser();



  throwIfError(error, 'Unable to read Cloudflare user');



  if (!user) {

    throw new Error('No authenticated Cloudflare user');

  }



  return user;

}



export async function getCurrentUser() {

  return getAuthenticatedUser();

}



export async function getCurrentGym() {

  const user = await getAuthenticatedUser();



  const {

    data: membership,

    error: membershipError,

  } = await backendClient

    .from('gym_users')

    .select('id, gym_id, role')

    .eq('id', user.id)

    .limit(1)

    .maybeSingle();



  throwIfError(membershipError, 'Unable to read gym membership');



  if (!membership) {

    throw new Error(

      'Authenticated user is not assigned to a Preface Fitness gym'

    );

  }



  const {

    data: gym,

    error: gymError,

  } = await backendClient

    .from('gyms')

    .select('*')

    .eq('id', membership.gym_id)

    .single();



  throwIfError(gymError, 'Unable to read gym');



  return gym;

}



async function getGymId() {

  const gym = await getCurrentGym();

  return gym.id;

}



async function selectTable(tableName, gymId) {

  const {

    data,

    error,

  } = await backendClient

    .from(tableName)

    .select('*')

    .eq('gym_id', gymId)

    .order('created_at', { ascending: false });



  throwIfError(error, `Unable to load ${tableName}`);



  return data || [];

}



const memberByCloudId = (members, id) =>

  members.find((m) => m.cloudId === id);



const memberByUiId = (members, id) =>

  members.find((m) => m.id === id);



const trainerByCloudId = (trainers, id) =>

  trainers.find((t) => t.cloudId === id);



function mapMembershipPlan(row) {

  return {

    id: row.id,

    cloudId: row.id,

    name: row.name || '',

    months: Number(row.months || 0),

    price: Number(row.price || 0),

    description: row.description || '',

  };

}



function mapMember(row) {

  return {

    id: row.member_code || row.id,

    cloudId: row.id,



    name: row.name || '',

    phone: row.phone || '',

    email: row.email || '',



    dob: row.dob || '',

    birthday: row.dob || '',

    gender: row.gender || '',

    address: row.address || '',

    emergencyContact: row.emergency_contact || '',



    plan: row.plan_name || '',

    start: row.start_date || '',

    expiry: row.expiry_date || '',

    status: row.status || 'Active',



    visits: Number(row.visits || 0),



    due: Number(

      row.due_amount ??

      row.due ??

      0

    ),



    amount: Number(

      row.membership_amount ??

      row.amount ??

      0

    ),



    paid: Number(

      row.paid_amount ??

      row.paid ??

      0

    ),



    height: row.height || '',

    weight: row.weight || '',

    currentWeight: row.weight || '',

    bodyFat: row.body_fat || '',

    trainer: row.trainer_name || '',



    referral: row.referral_source || '',

    notes: row.notes || '',

    // Support both current and legacy D1 member photo columns.
    photo: row.photo || row.photo_url || row.metadata?.photo || row.metadata?.photoUrl || '',

    dietPreference: row.diet_preference || '',

    attendanceNumber: row.attendance_number || '',



    referralPoints: Number(

      row.referral_points || 0

    ),



    referredBy:

      row.referred_by_member_code ||

      row.referred_by_member_id ||

      '',



    referredClients: Number(

      row.referred_clients || 0

    ),



    createdAt: row.created_at || '',

  };

}



function mapLead(row) {

  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    name: row.name || '',

    phone: row.phone || '',

    email: row.email || '',



    source: row.source || '',

    stage: row.stage || 'New',



    followUp: row.follow_up_date || '',

    interestedPlan: row.interested_plan || '',



    notes: row.notes || '',

    lastContact: row.last_contact || '',



    convertedMemberId:

      row.converted_member_code || '',



    convertedAt:

      row.converted_at || '',

  };

}



function mapPayment(row, members) {

  const member = memberByCloudId(

    members,

    row.member_id

  );



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    memberId: member?.id || '',

    member: member?.name || '',



    amount: Number(row.amount || 0),



    type:

      row.payment_type ||

      'Membership',



    mode: row.payment_mode || '',

    date: row.payment_date || '',

    notes: row.notes || '',



    invoiceNumber:

      row.invoice_number || '',



    gstApplicable:

      Boolean(row.gst_applicable),



    gstRate:

      Number(row.gst_rate || 0),



    taxableAmount:

      Number(row.taxable_amount || 0),



    cgstAmount:

      Number(row.cgst_amount || 0),



    sgstAmount:

      Number(row.sgst_amount || 0),



    invoiceAmount:

      Number(row.invoice_amount || 0),



    paidAmountAtInvoice:

      Number(row.paid_amount_at_invoice || 0),



    balanceAtInvoice:

      Number(row.balance_at_invoice || 0),



    description:

      row.description || '',

  };

}



function mapAttendance(row, members) {

  const member = memberByCloudId(

    members,

    row.member_id

  );



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    memberId: member?.id || '',

    member: member?.name || '',



    date:

      row.attendance_date || '',



    time:

      row.check_in_time || '',



    latitude:

      row.latitude ?? null,



    longitude:

      row.longitude ?? null,



    distance:

      row.distance_meters ?? null,



    source:

      row.source || 'Manual',

  };

}



function mapTrainer(row) {
  return {
    id: row.legacy_id || row.id, cloudId: row.id,
    name: row.name || '', phone: row.phone || '', specialization: row.specialization || '',
    experience: Number(row.experience || 0), status: row.status || 'Active',
    monthlySalary: Number(row.monthly_salary || 0), notes: row.notes || '',
    tier: row.tier || 'Silver', ptPricing: row.pt_pricing || {},
  };
}



function mapPTSession(row, members, trainers) {
  const member = memberByCloudId(members, row.member_id);
  const trainer = trainerByCloudId(trainers, row.trainer_id);
  const expiryDate = row.expiry_date || '';
  const storedStatus = row.status || 'Scheduled';
  const status = !['Cancelled','Completed'].includes(storedStatus) && expiryDate && expiryDate < new Date().toISOString().slice(0,10) ? 'Expired' : storedStatus;
  return {
    id: row.legacy_id || row.id, cloudId: row.id,
    memberId: member?.id || '', member: member?.name || '',
    trainerId: trainer?.id || '', trainer: trainer?.name || '',
    date: row.session_date || '', startTime: '', endTime: '', time: '', duration: 0,
    type: row.session_type || 'Personal Training', status,
    fee: Number(row.amount || 0), amount: Number(row.amount || 0), notes: row.notes || '',
    planName: row.plan_name || row.session_type || 'Monthly',
    sessionsTotal: Number(row.sessions_total || 22),
    sessionsCompleted: Number(row.sessions_completed || 0),
    validityDays: Number(row.validity_days || 30), expiryDate,
  };
}



function mapProgressRecord(row, members) {

  const member = memberByCloudId(

    members,

    row.member_id

  );



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    memberId:

      member?.id || '',



    date:

      row.record_date || '',



    weight:

      row.weight ?? '',



    bodyFat:

      row.body_fat ?? '',



    chest:

      row.chest ?? '',



    waist:

      row.waist ?? '',



    hips:

      row.hips ?? '',



    arms:

      row.arms ?? '',



    thighs:

      row.thighs ?? '',



    neck:

      row.neck ?? '',



    notes:

      row.notes || '',



    photos:

      row.photos || {

        front: '',

        side: '',

        back: '',

      },

  };

}



function mapWorkoutPlan(row, members) {

  const ids = Array.isArray(

    row.assigned_member_ids

  )

    ? row.assigned_member_ids

    : [];



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    name:

      row.name || '',



    goal:

      row.goal || '',



    level:

      row.level || '',



    durationWeeks:

      Number(row.duration_weeks || 0),



    trainer:

      row.trainer_name || '',



    notes:

      row.notes || '',



    assignedMemberIds:

      ids

        .map((x) =>

          memberByCloudId(

            members,

            x

          )?.id

        )

        .filter(Boolean),



    exercises:

      row.exercises || [],



    createdAt:

      row.created_at || '',

  };

}



function mapDietPlan(row, members) {

  const ids = Array.isArray(

    row.assigned_member_ids

  )

    ? row.assigned_member_ids

    : [];



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    name:

      row.name || '',



    goal:

      row.goal || '',



    calories:

      Number(row.calories || 0),



    protein:

      Number(row.protein || 0),



    durationWeeks:

      Number(row.duration_weeks || 0),



    coach:

      row.coach || '',



    notes:

      row.notes || '',



    assignedMemberIds:

      ids

        .map((x) =>

          memberByCloudId(

            members,

            x

          )?.id

        )

        .filter(Boolean),



    meals:

      row.meals || [],



    createdAt:

      row.created_at || '',

  };

}



function mapCommunicationLog(row, members) {

  const member = memberByCloudId(

    members,

    row.member_id

  );



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    memberId:

      member?.id || '',



    member:

      member?.name || '',



    channel:

      row.channel || '',



    direction:

      row.direction || '',



    template:

      row.template || '',



    subject:

      row.subject || '',



    message:

      row.message || '',



    status:

      row.status || '',



    date:

      row.communication_date ||

      row.sent_at ||

      '',



    time:

      row.communication_time ||

      '',



    createdAt:

      row.created_at || '',

  };

}



function mapFeedback(row, members) {

  const member = memberByCloudId(

    members,

    row.member_id

  );



  return {

    id: row.legacy_id || row.id,

    cloudId: row.id,



    memberId:

      member?.id || '',



    memberName:

      row.member_name ||

      member?.name ||

      '',



    category:

      row.category ||

      'General',



    priority:

      row.priority ||

      'medium',



    feedback:

      row.feedback ||

      '',



    status:

      row.status ||

      'Open',



    date:

      row.feedback_date ||

      '',



    notes:

      row.notes ||

      '',



    createdAt:

      row.created_at ||

      '',

  };

}



function parseSetting(value) {

  if (

    value === null ||

    value === undefined

  ) {

    return value;

  }



  if (

    typeof value !== 'string'

  ) {

    return value;

  }



  try {

    return JSON.parse(value);

  } catch {

    return value;

  }

}



function buildSettings(rows) {

  const out = {};



  for (const row of rows) {

    if (row.setting_key && !String(row.setting_key).startsWith('staff_profile_')) {

      out[row.setting_key] =

        parseSetting(

          row.setting_value

        );

    }

  }



  return out;

}



export async function loadCloudState() {

  const gym = await getCurrentGym();

  const gymId = gym.id;



  const [

    membershipPlans,

    membersRows,

    leads,

    paymentsRows,

    attendanceRows,

    trainersRows,

    ptRows,

    progressRows,

    workoutRows,

    dietRows,

    communicationRows,

    feedbacksRows,

    settingsRows,

  ] = await Promise.all([

    selectTable(

      TABLES.membershipPlans,

      gymId

    ),



    selectTable(

      TABLES.members,

      gymId

    ),



    selectTable(

      TABLES.leads,

      gymId

    ),



    selectTable(

      TABLES.payments,

      gymId

    ),



    selectTable(

      TABLES.attendance,

      gymId

    ),



    selectTable(

      TABLES.trainers,

      gymId

    ),



    selectTable(

      TABLES.ptSessions,

      gymId

    ),



    selectTable(

      TABLES.progressRecords,

      gymId

    ),



    selectTable(

      TABLES.workoutPlans,

      gymId

    ),



    selectTable(

      TABLES.dietPlans,

      gymId

    ),



    selectTable(

      TABLES.communicationLogs,

      gymId

    ),



    selectTable(

      TABLES.feedbacks,

      gymId

    ),



    selectTable(

      TABLES.appSettings,

      gymId

    ),

  ]);



  const members =

    membersRows.map(mapMember);



  const trainers =

    trainersRows.map(mapTrainer);



  const mappedFeedbacks = feedbacksRows.map((row) => mapFeedback(row, members));
  const regularFeedbacks = mappedFeedbacks.filter((item) => item.category !== 'Website Enquiry');
  const websiteEnquiries = mappedFeedbacks.filter((item) => item.category === 'Website Enquiry');



  return {

    gym,



    membershipPlans:

      membershipPlans.map(

        mapMembershipPlan

      ),



    members,



    leads:

      leads.map(mapLead),



    payments:

      paymentsRows.map(

        (r) =>

          mapPayment(

            r,

            members

          )

      ),



    attendance:

      attendanceRows.map(

        (r) =>

          mapAttendance(

            r,

            members

          )

      ),



    trainers,



    ptSessions:

      ptRows.map(

        (r) =>

          mapPTSession(

            r,

            members,

            trainers

          )

      ),



    progressRecords:

      progressRows.map(

        (r) =>

          mapProgressRecord(

            r,

            members

          )

      ),



    workoutPlans:

      workoutRows.map(

        (r) =>

          mapWorkoutPlan(

            r,

            members

          )

      ),



    dietPlans:

      dietRows.map(

        (r) =>

          mapDietPlan(

            r,

            members

          )

      ),



    communicationLogs:

      communicationRows.map(

        (r) =>

          mapCommunicationLog(

            r,

            members

          )

      ),



    // Keep website enquiries separate from regular Customer Feedback.
  feedbacks: regularFeedbacks,
  websiteEnquiries,



    settings:

      buildSettings(

        settingsRows

      ),

  };

}



export async function insertRecord(

  tableName,

  payload

) {

  const gymId =

    await getGymId();



  const {

    data,

    error,

  } = await backendClient

    .from(tableName)

    .insert({

      ...payload,

      gym_id: gymId,

    })

    .select()

    .single();



  throwIfError(

    error,

    `Unable to insert into ${tableName}`

  );



  return data;

}



export async function updateRecord(

  tableName,

  id,

  payload

) {

  const gymId =

    await getGymId();



  const {

    data,

    error,

  } = await backendClient

    .from(tableName)

    .update(payload)

    .eq('id', id)

    .eq('gym_id', gymId)

    .select()

    .single();



  throwIfError(

    error,

    `Unable to update ${tableName}`

  );



  return data;

}



export async function deleteRecord(

  tableName,

  id

) {

  const gymId =

    await getGymId();



  const {

    error,

  } = await backendClient

    .from(tableName)

    .delete()

    .eq('id', id)

    .eq('gym_id', gymId);



  throwIfError(

    error,

    `Unable to delete from ${tableName}`

  );



  return true;

}



/*

 * FIX:

 * app_settings.setting_value is JSONB.

 *

 * We now store the value directly instead of

 * JSON.stringify(value).

 *

 * This is important for:

 *   publicPage

 *   publicPage.trainers

 *   publicPage.packages

 *   membershipPrices

 *

 * It also uses an atomic UPSERT against:

 *   gym_id + setting_key

 */

export async function saveSettings(

  settings

) {

  const gymId =

    await getGymId();



  const entries =

    Object.entries(

      settings || {}

    );



  if (!entries.length) {

    return settings;

  }



  const rows =

    entries.map(

      ([key, value]) => ({

        gym_id: gymId,



        setting_key:

          key,



        /*

         * IMPORTANT:

         * Do NOT JSON.stringify here.

         * Cloudflare column is JSONB.

         */

        setting_value:

          value,

      })

    );



  const {

    error,

  } = await backendClient

    .from(TABLES.appSettings)

    .upsert(

      rows,

      {

        onConflict:

          'gym_id,setting_key',

      }

    );



  throwIfError(

    error,

    'Unable to save gym settings'

  );



  return settings;

}



export async function publicCheckIn({

  gymId,

  memberNumber,

  latitude,

  longitude,

  gymLatitude,

  gymLongitude,

}) {

  const {

    data,

    error,

  } = await backendClient.rpc(

    'public_check_in',

    {

      p_gym_id:

        gymId,



      p_member_number:

        String(

          memberNumber || ''

        ).trim(),



      p_lat:

        Number(latitude),



      p_lng:

        Number(longitude),



      p_gym_lat:

        Number(gymLatitude),



      p_gym_lng:

        Number(gymLongitude),

    }

  );



  throwIfError(

    error,

    'Unable to mark attendance'

  );



  return (

    data || {

      success: false,

      message:

        'Attendance service returned no response.',

    }

  );

}



export async function publicSubmitFeedback({

  gymId,

  memberName,

  category,

  priority,

  feedback,

}) {

  const {

    data,

    error,

  } = await backendClient.rpc(

    'public_submit_feedback',

    {

      p_gym_id:

        gymId,



      p_member_name:

        String(

          memberName || ''

        ).trim(),



      p_category:

        String(

          category ||

          'General'

        ).trim(),



      p_priority:

        String(

          priority ||

          'medium'

        )

          .trim()

          .toLowerCase(),



      p_feedback:

        String(

          feedback || ''

        ).trim(),

    }

  );



  throwIfError(

    error,

    'Unable to submit feedback'

  );



  return (

    data || {

      success: true,

    }

  );

}




export async function publicSubmitEnquiry({ gymId, name, phone, email, interestedPlan, message }) {
  // Reuse the existing public_submit_feedback RPC and feedbacks table.
  // This avoids adding a new database function/table or running a migration.
  const cleanName = String(name || '').trim();
  const cleanPhone = String(phone || '').trim();
  const cleanEmail = String(email || '').trim();
  const cleanPlan = String(interestedPlan || '').trim();
  const cleanMessage = String(message || '').trim();
  const enquiryText = [
    `Phone: ${cleanPhone}`,
    `Email: ${cleanEmail || 'Not provided'}`,
    `Interested in: ${cleanPlan || 'Not specified'}`,
    `Message: ${cleanMessage || 'No additional message provided.'}`,
  ].join('\n');

  const { data, error } = await backendClient.rpc('public_submit_feedback', {
    p_gym_id: String(gymId || '').trim(),
    p_member_name: cleanName,
    p_category: 'Website Enquiry',
    p_priority: 'medium',
    p_feedback: enquiryText,
  });
  throwIfError(error, 'Unable to submit customer enquiry');
  return data || { success: true };
}

export async function getMyAccess() {

  const {

    data,

    error,

  } = await backendClient.rpc(

    'get_my_access'

  );



  throwIfError(

    error,

    'Unable to read user permissions'

  );



  return (

    data || {

      role: 'staff',

      permissions: {},

    }

  );

}



export async function provisionStaffLogin({ email, password, displayName = '', permissions = {} }) {
  const { data, error } = await backendClient.rpc('provision_staff_login', {
    p_email: email,
    p_password: password,
    p_display_name: displayName,
    p_permissions: permissions,
  });
  throwIfError(error, 'Unable to provision staff login');
  return data;
}


export async function getGymStaff() {

  const {

    data,

    error,

  } = await backendClient.rpc(

    'get_gym_staff'

  );



  throwIfError(

    error,

    'Unable to load staff accounts'

  );



  return data || [];

}



export async function updateStaffPermissions(

  userId,

  permissions

) {

  const {

    data,

    error,

  } = await backendClient.rpc(

    'update_staff_permissions',

    {

      p_user_id:

        userId,



      p_permissions:

        permissions,

    }

  );



  throwIfError(

    error,

    'Unable to update staff permissions'

  );



  return data;

}



export async function setStaffActive(

  userId,

  isActive

) {

  const {

    data,

    error,

  } = await backendClient.rpc(

    'set_staff_active',

    {

      p_user_id:

        userId,



      p_is_active:

        isActive,

    }

  );



  throwIfError(

    error,

    'Unable to update staff status'

  );



  return data;

}

export async function saveStaffProfile(userId, { displayName = '', avatar = '' } = {}) {
  const { data, error } = await backendClient.rpc('set_staff_profile', {
    p_user_id: userId,
    p_display_name: displayName,
    p_avatar: avatar,
  });
  throwIfError(error, 'Unable to save staff profile');
  return data;
}

export async function deleteStaffLogin(userId) {
  const { data, error } = await backendClient.rpc('delete_staff_login', {
    p_user_id: userId,
  });
  throwIfError(error, 'Unable to delete staff account');
  return data;
}
